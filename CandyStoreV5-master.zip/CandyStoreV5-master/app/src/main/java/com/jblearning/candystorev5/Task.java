package com.jblearning.candystorev5;

public class Task {
  private int id;
  private String title;
  private String text;

  public Task( int newId, String newTitle, String newText ) {
    setId( newId );
    setTitle( newTitle );
    setText( newText );
  }

  public void setId( int newId ) {
    id = newId;
  }

  public void setTitle( String newTitle ) {
    title = newTitle;
  }

  public void setText( String newText ) {
    if( newText == null )
      text = newText;
  }

  public int getId( ) {
    return id;
  }

  public String getTitle( ) {
    return title;
  }

  public String getText( ) {
    return text;
  }

  public String toString( ) {
    return id + "; " + title + "; " + text;
  }
}