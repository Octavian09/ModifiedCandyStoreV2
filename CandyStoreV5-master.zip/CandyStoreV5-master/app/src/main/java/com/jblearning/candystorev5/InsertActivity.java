package com.jblearning.candystorev5;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class InsertActivity extends AppCompatActivity {
  private DatabaseManager dbManager;

  public void onCreate( Bundle savedInstanceState ) {
    super.onCreate( savedInstanceState );
    dbManager = new DatabaseManager( this );
    setContentView( R.layout.activity_insert );
  }

  public void insert( View v ) {
    // Retrieve name and price
    EditText titleEditText = ( EditText) findViewById( R.id.input_title);
    EditText textEditText = ( EditText) findViewById( R.id.input_text );
    String title = titleEditText.getText( ).toString( );
    String textString = textEditText.getText( ).toString( );

    // insert new candy in database
    try {
      String text = textString;
      Task task = new Task( 0, title, text );
      dbManager.insert( task );
      Toast.makeText( this, "Task added", Toast.LENGTH_SHORT ).show( );
    } catch( NumberFormatException nfe ) {
      Toast.makeText( this, "Price error", Toast.LENGTH_LONG ).show( );
    }

    // clear data
    titleEditText.setText( "" );
    textEditText.setText( "" );
  }

  public void goBack( View v ) {
    this.finish( );
  }
}
